package br.sp.etec.sebrae.OficinaAprender.Entity.Postagem.Anexo;

import br.sp.etec.sebrae.OficinaAprender.Entity.Postagem.Postagem;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
public class Anexo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(
            name = "idPostagem",
            foreignKey = @ForeignKey(name = "fk_postagem")
    )
     private Postagem postagem;

    private String nome;

    private String urlArquivo;

    private Long tamanhoArquivo;

    private String tipoArquivo;

    private Long arquivoId;
    
    private LocalDateTime dataUpload;

}
